window.addEventListener('DOMContentLoaded',function(e){
    console.log('ready');
})